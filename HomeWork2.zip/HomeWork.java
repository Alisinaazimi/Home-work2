/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package home.work;

/**
 *
 * @author alisina
 */
public class HomeWork {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {System.out.println("name:alisinaazimi");
    {System.out.println("f/name:M.ali");
    {System.out.println("dste of birth:2004/5/23");
    System.out.println("date of place:wardak");
            System.out.println("gmail address:alisinaazimi888@gmail.com");
                    
            
    }
    }
        // TODO code application logic here
    }
    
}
